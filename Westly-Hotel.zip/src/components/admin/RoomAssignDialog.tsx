import { useState, useMemo, useEffect } from "react";
import { useAuth } from "@/contexts/AuthContext";
import { useCollection } from "@/hooks/useFirebase";
import { where } from "firebase/firestore";
import { assignRoomsToHousekeeper } from "@/lib/housekeeping";
import { useToast } from "@/hooks/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Loader2, Search, BedDouble } from "lucide-react";

interface RoomAssignDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  /** Pre-select rooms — used when "Reassign" is clicked from an existing assignment row. */
  preselectedRoomIds?: string[];
  /** Pre-fill the target housekeeper — e.g. editing an existing group. */
  defaultHousekeeperId?: string;
  onDone?: () => void;
}

function toDateInputValue(d: Date | null): string {
  if (!d) return "";
  return d.toISOString().slice(0, 10);
}

export default function RoomAssignDialog({
  open, onOpenChange, preselectedRoomIds, defaultHousekeeperId, onDone,
}: RoomAssignDialogProps) {
  const { adminUser, role } = useAuth();
  const { toast } = useToast();
  const { data: rooms } = useCollection<any>("rooms", [where("isDeleted", "!=", true)]);
  const { data: users } = useCollection<any>("users", [where("status", "==", "active")]);

  const [housekeeperId, setHousekeeperId] = useState(defaultHousekeeperId || "");
  const [selectedRoomIds, setSelectedRoomIds] = useState<string[]>(preselectedRoomIds || []);
  const [search, setSearch] = useState("");
  const [startDate, setStartDate] = useState(toDateInputValue(new Date()));
  const [hasEndDate, setHasEndDate] = useState(true);
  const [endDate, setEndDate] = useState(() => {
    const d = new Date();
    d.setMonth(d.getMonth() + 1);
    return toDateInputValue(d);
  });
  const [notes, setNotes] = useState("");
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (open) {
      setHousekeeperId(defaultHousekeeperId || "");
      setSelectedRoomIds(preselectedRoomIds || []);
      setSearch("");
      setNotes("");
    }
  }, [open]); // eslint-disable-line react-hooks/exhaustive-deps

  const housekeepers = useMemo(
    () => users.filter((u: any) => u.role === "housekeeping").sort((a: any, b: any) => (a.name || "").localeCompare(b.name || "")),
    [users]
  );

  const filteredRooms = useMemo(() => {
    let pool = [...rooms];
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      pool = pool.filter((r: any) => r.number?.toLowerCase().includes(q) || r.type?.toLowerCase().includes(q));
    }
    return pool.sort((a: any, b: any) => (a.number || "").localeCompare(b.number || "", undefined, { numeric: true }));
  }, [rooms, search]);

  const toggleRoom = (id: string) => {
    setSelectedRoomIds(prev => prev.includes(id) ? prev.filter(x => x !== id) : [...prev, id]);
  };

  const handleSubmit = async () => {
    if (!adminUser) return;
    if (!housekeeperId) {
      toast({ title: "Select a housekeeper", variant: "destructive" });
      return;
    }
    if (selectedRoomIds.length === 0) {
      toast({ title: "Select at least one room", variant: "destructive" });
      return;
    }
    if (hasEndDate && endDate && startDate && endDate < startDate) {
      toast({ title: "Invalid dates", description: "End date must be on or after the start date.", variant: "destructive" });
      return;
    }
    setSaving(true);
    try {
      const housekeeper = housekeepers.find((u: any) => u.id === housekeeperId);
      const selectedRooms = rooms
        .filter((r: any) => selectedRoomIds.includes(r.id))
        .map((r: any) => ({ id: r.id, number: r.number }));

      await assignRoomsToHousekeeper({
        housekeeperId,
        housekeeperName: housekeeper?.name || "Housekeeper",
        rooms: selectedRooms,
        startDate: new Date(`${startDate}T00:00:00Z`),
        endDate: hasEndDate && endDate ? new Date(`${endDate}T00:00:00Z`) : null,
        notes: notes || null,
        actor: { id: adminUser.id, name: adminUser.name, role },
      });

      toast({
        title: "Rooms Assigned",
        description: `${selectedRooms.length} room${selectedRooms.length === 1 ? "" : "s"} assigned to ${housekeeper?.name}.`,
      });
      onOpenChange(false);
      onDone?.();
    } catch (err: any) {
      toast({ title: "Failed to assign rooms", description: err?.message, variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>Assign Rooms to Housekeeper</DialogTitle>
        </DialogHeader>

        <div className="space-y-4">
          <div className="space-y-1.5">
            <Label>Housekeeper</Label>
            <Select value={housekeeperId} onValueChange={setHousekeeperId}>
              <SelectTrigger><SelectValue placeholder="Select housekeeper" /></SelectTrigger>
              <SelectContent>
                {housekeepers.map((u: any) => (
                  <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>
                ))}
                {housekeepers.length === 0 && (
                  <div className="px-2 py-1.5 text-xs text-muted-foreground">No active housekeeping staff found.</div>
                )}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label>Start Date</Label>
              <Input type="date" value={startDate} onChange={e => setStartDate(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <Label>End Date</Label>
                <button
                  type="button"
                  className="text-xs text-primary underline underline-offset-2"
                  onClick={() => setHasEndDate(v => !v)}
                >
                  {hasEndDate ? "Make ongoing" : "Set end date"}
                </button>
              </div>
              <Input type="date" value={endDate} onChange={e => setEndDate(e.target.value)} disabled={!hasEndDate} />
            </div>
          </div>
          {!hasEndDate && (
            <p className="text-xs text-muted-foreground -mt-2">
              No end date — this assignment stays active until it's edited or ended.
            </p>
          )}

          <div className="space-y-1.5">
            <Label>Special Instructions (optional)</Label>
            <Textarea
              value={notes}
              onChange={e => setNotes(e.target.value)}
              placeholder="e.g. VIP wing, extra care with fixtures, guest has allergy notes on file..."
              rows={2}
            />
          </div>

          <div className="space-y-1.5">
            <div className="flex items-center justify-between">
              <Label>Rooms ({selectedRoomIds.length} selected)</Label>
              <div className="relative w-40">
                <Search className="absolute left-2 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <Input className="pl-7 h-8 text-xs" placeholder="Search rooms" value={search} onChange={e => setSearch(e.target.value)} />
              </div>
            </div>
            <div className="border rounded-md max-h-56 overflow-y-auto divide-y">
              {filteredRooms.map((r: any) => (
                <label key={r.id} className="flex items-center gap-2 px-3 py-2 text-sm cursor-pointer hover:bg-muted/50">
                  <Checkbox checked={selectedRoomIds.includes(r.id)} onCheckedChange={() => toggleRoom(r.id)} />
                  <BedDouble className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
                  <span className="font-medium">Room {r.number}</span>
                  <span className="text-muted-foreground text-xs">{r.type}</span>
                  {r.status && <Badge variant="outline" className="ml-auto text-[10px]">{r.status}</Badge>}
                </label>
              ))}
              {filteredRooms.length === 0 && (
                <div className="px-3 py-6 text-center text-xs text-muted-foreground">No rooms match.</div>
              )}
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)} disabled={saving}>Cancel</Button>
          <Button onClick={handleSubmit} disabled={saving}>
            {saving && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
            Assign Rooms
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
